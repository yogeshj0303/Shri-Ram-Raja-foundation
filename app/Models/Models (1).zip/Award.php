<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Award extends Model
{
    protected $fillable = ['awards_image'];

    // Add any additional model methods or relationships here
}