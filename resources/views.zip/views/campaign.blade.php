@extends('layout.main')

@section('main.container')







<section class="page-title bg-1">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="block text-center">

          <span class="text-white">What we do</span>

          <h1 class="text-capitalize mb-4 text-lg">Our Recent Compaign</h1>

        </div>

      </div>

    </div>

  </div>

</section>



<!-- Section About Start -->

<section class="section causes">

	<div class="container">

		<div class="row mt-4">
			@foreach($campaigns as $campaign)
			<div class="col-lg-4 col-md-6">

				<div class="card mb-4 cause-item">

				  <div class="row no-gutters">

				      <img src="{{url('/assets/images/campaign')}}/{{$campaign->feature_image}}" class="img-fluid w-100" alt="..." style="height:200px;">



				      <div class="card-body">

				        <h3 class="mb-3 text-center"><a href="{{url('/')}}/campaign/{{$campaign->id}}" style="color:black;">{{$campaign->title}}</a></h3>



				         <ul class="list-inline border-bottom border-top py-3 ">

				        	<li class="list-inline-item"><i class="icofont-check text-color mr-2"></i>Goal:	<span>{{\App\Donation::getDonations($campaign->id)}} {{$language->donations}}</span></li>

				        </ul>

				        <p class="card-text mb-4">{{ substr(strip_tags($campaign->description), 0, 120) }}...</p>



				        <a href="{{url('campaign/5/donate')}}" class="btn btn-main rounded">{{$language->donate}}</a>

				      </div>

				  </div>

				</div>

			</div>
			@endforeach
		</div>

	</div>

</section>





@endsection