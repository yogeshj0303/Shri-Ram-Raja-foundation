@extends('layout.main')



@section('main.container')











<section class="page-title bg-1">



  <div class="container">



    <div class="row">



      <div class="col-md-12">



        <div class="block text-center">



          <span class="text-white">Contact Us</span>



          <h1 class="text-capitalize mb-4 text-lg">Get in Touch</h1>



        </div>



      </div>



    </div>



  </div>



</section>











<section class="section">



    <div class="container">



        <div class="row">



             <div class="col-lg-6 col-sm-12 ">



                <div class="contact-content mt-5">



                    <h2 class="mb-5">We’d love to hear from you! <br>Give us call, send us a message?</h2>



                    <ul class="address-block list-unstyled">



                        <li>



                            <h6 class="mb-2">Address</h6>



                            552, Chick Mohalla Sader Bazar,

                            Jhansi U.P. - 284001





                        </li>



                        <li>



                            <h6 class="mb-2">email us</h6>



                            aasrajhansi@gmail.com



                        </li>



                        <li>



                            <h6 class="mb-2">Phone Number</h6>



                            0988-999110<br>

                          +91 091408 90592



                        </li>



                    </ul>







                    <ul class="social-icons list-inline mt-5">



                       <li> <h6 class="mb-3">Find us on social media</h6></li>



                        <li class="list-inline-item">



                            <a href="#"><i class="icofont-facebook mr-2"></i></a>



                        </li>



                        <li class="list-inline-item">



                            <a href="#"><i class="icofont-twitter mr-2"></i></a>



                        </li>



                        <li class="list-inline-item">



                            <a href="#"><i class="icofont-linkedin mr-2"></i></a>



                        </li>



                    </ul>



                </div>



            </div>



            <div class="col-lg-5 col-sm-12 mt-2 ">



                <div class="google-map mt-5 mt-lg-0">



                    <div id="map"></div>



                </div>



            </div>



        </div>



    </div>



</section>







<!-- contact form start -->



<section class="contact-wrap section-bottom">



    <div class="container">



        <div class="row">



            <div class="col-lg-12 col-md-12 col-sm-12">



                
                 

                    <span class="text-color">Send a message</span>



                    <h3 class="text-md mb-5">Contact Form</h3>



                 <!-- form message -->


                    <div class="row">



                        <div class="col-12">



                            <div class="alert alert-success contact__msg" style="display: none" role="alert">



                                Your message was sent successfully.



                            </div>



                        </div>



                    </div>



                    <!-- end message -->



                    <form id="contact-form" class="contact__form" method="post" action="{{ route('contact.store') }}">
                        {{csrf_field()}}
                  <div class="row">



                      <div class="col-lg-6">



                           <div class="form-group">



                                <label>Your Name <span class="text-danger">*</span></label>



                                <input name="name" type="text" class="form-control" required="" >



                            </div>



                      </div>



                      <div class="col-lg-6">



                           <div class="form-group">



                            <label>Your Email <span class="text-danger">*</span></label>



                            <input name="email" type="email" class="form-control" required="">



                        </div>



                      </div>



                      <div class="col-lg-6">



                           <div class="form-group">



                                <label> Your Subject <span class="text-danger">*</span></label>



                                <input name="subject" type="text" class="form-control"required="" >



                            </div>



                      </div>



                      <div class="col-lg-6">



                            <div class="form-group">



                                <label>Your Phone Number <span class="text-danger">*</span></label>



                                <input name="number" type="number" class="form-control"required="" >



                            </div>



                      </div>



                  </div>



                    <div class="form-group mb-4">



                        <label>Your Message <span class="text-danger">*</span></label>



                        <textarea name="message" class="form-control" rows="6" required=""></textarea>



                    </div>



                    <button class="btn btn-main rounded" name="submit" type="submit">Send Message</button>



                </form>



            </div>



        </div>



    </div>



</section>











@endsection