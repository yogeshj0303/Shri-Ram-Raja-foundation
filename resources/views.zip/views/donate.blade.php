@extends('layout.main')

@section('main.container')





<section class="page-title bg-1">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="block text-center">

          <span class="text-white">Donation confirmation</span>

          <h1 class="text-capitalize mb-4 text-lg">Donation details</h1>

        </div>

      </div>

    </div>

  </div>

</section>



<section class="section donation">

	<div class="container">

		<div class="row">

			<div class="col-lg-8">

				<div class="donation-wrap">

					<h2 class="text-md mb-4">I want to support you</h2>

					<p class="mb-5 lead">In order to make an offline donation we ask that you please follow these instructions</p>

					<form method="POST" class="donation-form" id="payment_form">
						{{ csrf_field() }}


					  <fieldset class="form-group">

					    <div class="row">

					      <label class="col-form-label col-sm-3 pt-0 h3">Donation</label>

					      <div class="col-sm-9">

					        <div class="form-check">

					          <input class="form-check-input" type="radio" name="amount" id="gridRadios1" value="option1" checked>

					          <label class="form-check-label" for="gridRadios1">

					            Rs. 30,000/- (for the education of 5 children for 1 year)

					          </label>

					        </div>



					        <div class="form-check">

					          <input class="form-check-input" type="radio" name="amount" id="gridRadios2" value="option2">

					          <label class="form-check-label" for="gridRadios2">

					            Rs. 18,000/- (for the education of 3 children for 1 year)

					          </label>

					        </div>



					        <div class="form-check">

					          <input class="form-check-input" type="radio" name="amount" id="gridRadios3" value="option3">

					          <label class="form-check-label" for="gridRadios3">

					            Rs. 6,000/- (for the education of 1 child for 1 year) 

					          </label>

					        </div>

					        <div class="form-group row">

							    <label class="col-sm-4 col-form-label">Other amount: </label>

							    <div class="col-sm-8">

							      <input type="number" class="form-control" name="amount" id="inputamount" placeholder="25000">

							    </div>

							  </div>

					      </div>

					    </div>



					    <div class="form-group">

						    <label class="col-form-label mb-3 h3">Select Payment Method</label>

						    <ul class="list-group list-group-horizontal-lg">

							  <li class="list-group-item"><a href="#" style="color: black;"><i class="icofont-mastercard-alt mr-2"></i>Credit Card</a></li>

							  <li class="list-group-item"><a href="#" style="color: black;"><i class="icofont-bank-transfer-alt mr-2"></i>Bank Transfer</a></li>

							  <li class="list-group-item"><a href="#" style="color: black;"><i class="icofont-payoneer-alt mr-2"></i>Payoneer</a></li>

							</ul>

						 </div>



						 <h3 class="mb-4 mt-5 border-bottom pb-3">Your account Credential</h3>

						 <div class="form-group">

						    <label class="col-form-label mb-2">Name on card</label>

						    <input type="text" class="form-control" id="paycardname" placeholder="Your Name">

						 </div>

						 <div id="stripes" class="form-group">

						    <label class="col-form-label mb-2">Card Number</label>

						    <input type="text" class="form-control" id="paycardnumber" placeholder="0000-0000-0000-0000">

						 </div>



						   <div class="form-row">

						    <div class="form-group col-md-4">

						      <label>Month</label>

						      <select id="inputmonth" class="form-control">

						        <option selected>Choose...</option>

						        <option>2019</option>

						        <option>2018</option>

						      </select>

						    </div>



						    <div class="form-group col-md-4">

						      <label >Year</label>

						      <select id="inputyear" class="form-control">

						        <option selected>Choose...</option>

						        <option>2019</option>

						        <option>2018</option>

						      </select>

						    </div>

						    <div class="form-group col-md-4">

						      <label>CVV</label>

						      <input type="text" class="form-control" id="inputZip">

						    </div>

						  </div>



					  </fieldset>





					  <h2 class="mb-5 mt-5 border-bottom pb-3">Donor Details</h2>



					  <div class="form-group row">

					    <label class="col-sm-3 col-form-label">Your Name</label>

					    <div class="col-sm-9">

					      <input type="text" class="form-control" name="donator_name" id="inputname" placeholder="Your Name">

					    </div>

					  </div>



					  <div class="form-group row">

					    <label class="col-sm-3 col-form-label">Email</label>

					    <div class="col-sm-9">

					      <input type="email" class="form-control" name="donator_email" id="inputEmail3" placeholder="Email">

					    </div>

					  </div>





					  <div class="form-group row">

					    <label class="col-sm-3 col-form-label">Phone</label>

					    <div class="col-sm-9">

					      <input type="number" class="form-control" name="donator_phone" id="inputphone" placeholder="Phone">

					    </div>

					  </div>



					  {{-- <div class="form-group row">

					    <label class="col-sm-3 col-form-label">Country</label>

					    <div class="col-sm-9">

						      <select id="inputState" class="form-control">

						        <option selected>Choose Country</option>

						        <option>USA</option>

						        <option>Italy</option>

						        <option>BD</option>

						        <option>India</option>

						        <option>Pakistan</option>

						        <option>Japan</option>

						        <option>Nethdarland</option>

						        <option>China</option>

						      </select>

					    </div>

					  </div> --}}

					   <div class="form-group row">

					    <label class="col-sm-3 col-form-label">Address</label>

					    <div class="col-sm-9">

					      <input type="text" class="form-control" name="donator_address" id="inputname2" placeholder="Your Name">

					    </div>

					  </div>



					  <div class="form-group row">

					    <label class="col-sm-3 col-form-label">City</label>

					    <div class="col-sm-9">

					      <input type="text" class="form-control" name="donator_city" id="inputname3" placeholder="Your Name">

					    </div>

					  </div>



					  <div class="form-group row">

					    <div class="col-sm-3"> 

					    	<strong>Anonymous donation?</strong>

					    </div>

					    <div class="col-sm-9">

					      <div class="form-check">

					        <input class="form-check-input" type="checkbox" id="gridCheck1">

					        <label class="form-check-label">

					          Check this box to hide your personal info in our donators list

					        </label>

					      </div>

					    </div>

					  </div>

					  <div class="form-group row">

					    <div class="col-sm-12">

					      <div class="form-check">

					        <input class="form-check-input" type="checkbox" id="gridCheck2">

					        <label class="form-check-label">

					           I give my <span class="font-weight-bold">consent for authorized representatives</span> of Smile Foundation to contact me occasionally by mobile and email for informing on the latest developments and updated offerings.

					        </label>

					      </div>

					    </div>

					  </div>



					  <div class="form-group row mt-4">

					    <div class="col-sm-10">

							<button type="submit" class="theme-btn btn-style-two">Donate Now </button>

					    </div>

					  </div>

					</form>

				</div>

			</div>



			<div class="col-lg-4">

				<div class="offline-donation mt-5 mt-lg-0">

					<h4 class="mb-5">In order to make an offline donation we ask that you please follow these instructions:</h4>



					<ul class="list-unstyled">

						<li>1. Make a check payable to <span>"Aasra"</span></li>

						<li>2. On the memo line of the check, please indicate that the donation is for <span>"Aasra"</span></li>

						<li>3. Please mail your check to: 



							<address>

								552, Chick Mohalla Sader Bazar,
                                Jhansi U.P. - 284001

							</address>

						</li>

						<li>4. Email us in detials : <span>aasrajhansi@gmail.com</span></li>

						<li>5. Contact us at Phone: <span>+91 0988-999110, Mob: +91 91408 90592</span></li>
						<li>5. Contact us at Phone: <span>+91 0988-999110, Mob: +91 91408 90592</span></li>

					</ul>



					<p>All contributions will be gratefully acknowledged and are tax deductible.</p>

				</div>

			</div>

		</div>

	</div>

</section>




<script type="text/javascript">
	function meThods(val) { 
		   var action1 = "{{route('payment.submit')}}";
		   var action2 = "{{route('stripe.submit')}}";
		   if (val.value == "Paypal") {
			 $("#payment_form").attr("action", action1);
			 $("#stripes").hide();
		   }
		   if (val.value == "Stripe") {
			 $("#payment_form").attr("action", action2);
			 $("#stripes").show();
		   }
		   if (val.value == "") {
			 $("#payment_form").attr("action", "");
			 $("#stripes").hide();
		   }
	 }
 
	$('#anonym').click(function() {
		if($(this).is(":checked")){
			$("#details").hide();
			$("#details").find('input').attr('required',false);
		}else{
			$("#details").show();
			$("#details").find('input[name="name"]').attr('required',true);
			$("#details").find('input[name="email"]').attr('required',true);
		}
	});
 </script>
@endsection