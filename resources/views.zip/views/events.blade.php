@extends('layout.main')

@section('main.container')
<style>
    .card-title
    {
     color:black !important;   
    }
</style>

<section class="page-title bg-1">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="block text-center">

          <span class="text-white">{{$language->blog}}</span>

          <h1 class="text-capitalize mb-4 text-lg">All Events</h1>

        </div>

      </div>

    </div>

  </div>

</section>





<section class="section event">

	<div class="container">

		<div class="row justify-content-center mt-3">
			@foreach($blogs as $blog)
			{{--  <div class="col-lg-4 col-md-6">

				<div class="card event-item mb-4">

					  <img src="{{url('/')}}/assets/images/blog/{{$blog->featured_image}}" class="card-img-top" alt="..." >

					  <div class="card-body">

					    <h3 class="card-title"><a href="{{url('/')}}/event/{{$blog->id}}">{{$blog->title}}</h3>

					    <p class="card-text">{{$blog->details}}</p>

					  </div>

					  <ul class="list-group list-group-flush">

					    <li class="list-group-item"><strong>Date : </strong> {{date('d M Y',strtotime($blog->created_at))}}</li>




					  </ul>




				</div>

			</div>  --}}
			<div class="col-lg-4 col-md-6 mb-5 mb-lg-0">

				<div class="card blog-item ">
	
				   <img src="{{url('/')}}/assets/images/blog/{{$blog->featured_image}}" alt="" class="img-fluid" style="height:230px;">
	
				   <div class="card-body mt-2  ">
	
					  {{--  <span class="text-sm text-color text-uppercase font-weight-bold">{{date('d M Y',strtotime($blog->created_at))}}</span>  --}}
	
					  <h3 class="mb-3"><a href="{{url('/')}}/blog/{{$blog->id}}" class="">{{$blog->title}}</a></h3>
	
					  <p>{{substr(strip_tags($blog->details),0,125)}}</p>
	
				   </div>
	
				</div>
	
			 </div>



			@endforeach
			

		</div>

	</div>

</section>





@endsection