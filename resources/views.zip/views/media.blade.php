@extends('layout.main')

@section('main.container')
 

    <style>
    iframe
    {
        border-radius:5%;
    }
    img
    {
        border-radius:2%;
    }
section > .container, section > .container-fluid {
     padding-top: 0px; 
    padding-bottom: 60px;
}
/* Style the tab */
.tab {
    margin-top: 4%;
  overflow: hidden;
  /*border: 1px solid #ccc;*/
  /*background-color: #f1f1f1;*/
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  /*float: left;*/
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
  border-radius: 20px;
    border: 1px solid #ccc;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #87ceeb;
}

/* Create an active/current tablink class */
.tab button.active {
  /*background-color: #ccc;*/
      background-color: #7D2310;;
    color: white;
    font-weight: bold;
    border-radius: 23px
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 20px;
  /*border: 1px solid #ccc;*/
  border-top: none;
}
.galle_img img {
       width: 320px;
    height: 260px;
}
@media only screen and (max-width:375px){
   .galle_img img {
    width:310px !important;
    height:270px !important;  
}
}
@media only screen and (max-width:600px){
.galle_img img
{
  width:335px !important;
  height:300px !important;  
}
}
@media only screen and (max-width: 768px){
    .galle_img img
{
    width: 200px !important;
    height: 207px !important;
}
}

@media only screen and (max-width:1024px){
   .galle_img img {
    width: 285px !important;
    height: 260px !important;
}
}

</style>

  <div class="main-content">


<section class="page-title bg-1">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="block text-center">

          <span class="text-white">who we are</span>

          <h1 class="text-capitalize mb-4 text-lg">MEDIA</h1>

        </div>

      </div>

    </div>

  </div>

</section>
<section>
  <div class="container">
    <div class="section-content">
    
    <div class="tab">
      <center>    
          <button class="tablinks " onclick="openCity(event, 'London')"id="defaultOpen">GALLERY</button>
          <button class="tablinks" onclick="openCity(event, 'Paris')">VIDEO</button>
          <!--<button class="tablinks" onclick="openCity(event, 'Tokyo')">SEMINAR</button>-->
          <!--<button class="tablinks" onclick="openCity(event, 'SPORTS')">SPORTS GROUNDS</button>-->
      </center>
   </div>

<div id="London" class="tabcontent mt-5">
       <div class="row "> 
           @foreach($service_data as $temp)
            <div class="col-lg-4 col-md-4 col-sm-1"style="margin-top:3%;">  
             <div class="galle_img">
                 <!--<img src=""  class="service-icon">-->
              <img src="{{url('/assets/images/service')}}/{{$temp->icon}}" alt="" style="box-shadow:2px 5px 5px 5px grey;">
              </div>
          </div>
          @endforeach
          <!--<div class="col-lg-4 col-md-4 col-sm-1"style="margin-top:3%;"> -->
          <!-- <div class="galle_img">-->
          <!--    <img src="https://www.ngoregistration.org/wp-content/uploads/2018/06/NGO.jpg"  style="box-shadow:2px 5px 5px 5px grey;">-->
          <!--  </div>  -->
          <!--</div>-->
          
      
     </div>
</div>

<div id="Paris" class="tabcontent mt-5">
     <div class="row "> 
                @foreach ($test as $temp )

        <div class="col-lg-4 col-md-3 col-sm-2"style="margin-top:3%;">  
            <div class="video_gall">
             {!! Embed::make($temp->client)->parseUrl()->setAttribute([
                            'width' => '100%',
                            'height' => 315,
                            'frameborder' => 0,
                            'allowfullscreen' => true
                            ])->getHtml() !!}  
          </div>
         </div>      
          
                      @endforeach
  
         
    
     </div>
</div>

<!--<div id="SPORTS" class="tabcontent">-->
<!--     <div class="row "> -->
        
<!--             <div class="col-md-4 ">  -->
        
<!--              <img id="myImg" src="https://www.w3schools.com/howto/img_fjords.jpg" alt="Trolltunga, Norway" width="500" height="300" style="box-shadow:2px 5px 5px 5px grey;">-->

             <!-- The Modal -->
<!--               <div id="myModal" class="modal">-->
<!--                 <img class="modal-content" id="img01">-->
<!--              </div>-->

             
<!--          </div>-->
     
<!--     </div>-->
<!--</div>-->
      </div>
    </div>
  </div>
</section>

</div>
</section>

<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
  
}
document.getElementById("defaultOpen").click();
</script>
@endsection