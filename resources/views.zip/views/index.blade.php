



@extends('layout.main')

@section('main.container')

<!-- Slider Start -->
<div class="wrapper">
   <div class="carousel">
      <div class="slider" style="background: url({{asset('assets/images/sliders/slider.jpeg')}}) no-repeat; ">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-lg-12 col-md-12">
                  <div class="block text-center">
                     <!--<span class="d-block mb-3 text-white text-capitalize">Small help can make change</span>-->
                     <h1 class="animated fadeInUp mb-4">New hope for <br>near future</h1>
                   
                     <a href="{{url('campaign/5/donate')}}"class="btn btn-main animated fadeInUp rounded">Donate Now</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="slider" style="background: url({{asset('assets/images/bg/banner-1.jpg')}}) no-repeat;">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-lg-12 col-md-12">
                  <div class="block text-center">
                     <!--<span class="d-block mb-3 text-white text-capitalize">Small help can make change</span>-->
                     <h1 class="animated fadeInUp mb-4">Open Your Heart To Those In Need.</h1>
                     <!--<p class="mb-4">Your small contribution means a lot. Natus officia amet hic  <br>accusamus repellat magni reprehenderit dolorem.</p>-->
                     <a href="#" target="_blank" class="btn btn-main animated fadeInUp rounded">Donate Now</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="slider" style="background: url({{asset('assets/images/bg/banner-2.jpg')}}) no-repeat;">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-lg-12 col-md-12">
                  <div class="block text-center">
                     <!--<span class="d-block mb-3 text-white text-capitalize">Small help can make change</span>-->
                     <h1 class="animated fadeInUp mb-4">Many Are In Need Of Your Helping Hand.</h1>
                     <!--<p class="mb-4">Your small contribution means a lot. Natus officia amet hic  <br>accusamus repellat magni reprehenderit dolorem.</p>-->
                     <a href="#" target="_blank" class="btn btn-main animated fadeInUp rounded">Donate Now</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- <div><img src="https://picsum.photos/300/200?random=2"></div>
         <div><img src="https://picsum.photos/300/200?random=3"></div>
         <div><img src="https://picsum.photos/300/200?random=4"></div>
         <div><img src="https://picsum.photos/300/200?random=5"></div>
         <div><img src="https://picsum.photos/300/200?random=6"></div> -->
   </div>
</div>
<!-- Section Intro Start -->

<section class="section intro">

   <div class="container">

     <div class="row align-items-center">
      <!--   @if($pagesettings[0]->welcome_status)-->
        <div class="col-lg-8">

            <div class="section-title">

               <!--<span class="text-color ">   About Aasra Society NGO </span>-->

               <h2 class="mt-3 cont0ent-title">{{$pagesettings[0]->welcome_title}}</h2>


               <p style="text-align: justify;">{{$pagesettings[0]->welcome_description}}</p>

            </div>

         </div>
         @endif
        <div class="col-lg-4" style="">

          <div class="mb-4 story-item pad-10 center-item">

               <div class="row no-gutters">

                  <h3 class="text-center center-item mt-3 mb-3">

                     <a class="text-center" href="#">   Aasra Society</a>

                  </h3>
                  <img src="{{asset('assets/images/about/as11.jpg')}}" alt="" class="img-fluid w-100" style="height:275px;">

               

                  <p class="card-text mb-4"></p>

               </div>

            </div>

         </div>

      </div>

   </div>

   </div>

</section>




<section>


  







<!-- Section Intro END -->
<section class="section video">
   <div class="container">
      <div class="row ">
         <div class="col-lg-8 col-md-8 col-sm-12">
            <div class="video-content  mb-5 mb-lg-0">
               <h2 class="mt-3 mb-2 position-relative text-lg">Our Reach</h2>
               <p>
                  In keeping with its philosophy of 'Real Work Real Change', Aasra Society NGO Foundation , an NGO in Jhansi, India to support the underserved, has taken its intervention into the interiors of India, reaching the unreached in the remotest of rural areas and urban slums with our services and making this helping foundation in India, the best NGO in India.
               </p>
               <div class="counter-section">
         <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-6">
               <div class="counter-item-2 mb-5 mb-lg-0 pt-5">
                  <span class="counter-stat">5</span>
                  <p>Years of Experience</p>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
               <div class="counter-item-2 mb-5 mb-lg-0 pt-5">
                  <span class="counter-stat font-weight-bold ">500</span>
                  <p>Active Volunteer</p>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
               <div class="counter-item-2 mb-5 mb-lg-0 pt-5">
                  <span class="counter-stat">1</span>
                  <p>Availble Country</p>
               </div>
            </div>
         
         </div>
      </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
            <!-- <div class="video-block">
               <div class="img-block"> -->
                  <img src="{{asset('assets/images/map.png')}}" alt="" class="img-fluid">
               <!-- </div>            
            </div> -->
         </div>
      </div>
    
 
   </div>
</section>




<section class="gallery">

   <div class="container">

      <div class="row justify-content-center">

         <div class="col-lg-8 col-md-10">

            <div class="section-title text-center">

               <!--<span class="text-color">Our Gallery</span>-->

               <h2 class="mt-3 mb-4 position-relative content-title">We connect with people across different sectors. we take risksand we always keep learning.</h2>

            </div>

         </div>

      </div>

   </div>

   <div class="container-fluid">

      <div class="gallery-wrap">

         <div class="row">

            <div class="container-fluid">

               <div class="row">

                  <div class="bd-example bd-example-tabs">

                     <nav>

                        <div class="nav nav-tabs" id="nav-tab" role="tablist">

                    <a class="nav-item nav-link active text-center" id="nav-education-tab" data-toggle="tab" href="#nav-education" role="tab" aria-controls="nav-education" aria-selected="true"><span class="pad">Education</span></a>

                   <a class="nav-item nav-link text-center" id="nav-health-tab" data-toggle="tab" href="#nav-health" role="tab" aria-controls="nav-health" aria-selected="false"><span class="pad">Health</span></a>

                    <a class="nav-item nav-link text-center" id="nav-livelihood-tab" data-toggle="tab" href="#nav-livelihood" role="tab" aria-controls="nav-livelihood" aria-selected="false"><span class="pad">Livelihood</span></a>

                           <a class="nav-item nav-link text-center" id="nav-Woman-Empowerment" data-toggle="tab" href="#nav-Woman-Empowerment" role="tab" aria-controls="nav-Woman-Empowerment" aria-selected="false">Woman Empowerment</a>

                        </div>

                     </nav>

                     <div class="tab-content" id="nav-tabContent" >

                        <div class="tab-pane fade show active" id="nav-education" role="tabpanel" aria-labelledby="nav-education-tab">

						<div class="tab-slider">

                              <div class="tab-slider-inner" style="width:100%;  background: url({{asset('assets/images/bg/banner.jpg')}}) no-repeat;">

                                 <div class="container">

                                    <div class="row justify-content-center">

                                       <div class="col-lg-12 col-md-12">

                                          <div class="block text-center">

                                             <h1 class="animated fadeInUp mb-4">New hope for <br>near future</h1>

                                          </div>

                                       </div>

                                    </div>

                                 </div>

                              </div>

                              <div class="tab-slider-inner" style=" height:500px; width:100%;   background: url({{asset('assets/images/bg/banner-1.jpg')}}) no-repeat;">

                                 <div class="container">

                                    <div class="row justify-content-center">

                                       <div class="col-lg-12 col-md-12">

                                          <div class="block text-center">

                                             <h1 class="animated fadeInUp mb-4">Open Your Heart To Those In Need.</h1>

                                          </div>

                                       </div>

                                    </div>

                                 </div>

                              </div>

                              <div class="tab-slider-inner" style="  width:100%; background: url({{asset('assets/images/bg/banner-2.jpg')}}) no-repeat;">

                                 <div class="container">

                                    <div class="row justify-content-center">

                                       <div class="col-lg-12 col-md-12">

                                          <div class="block text-center">

                                             <h1 class="animated fadeInUp mb-4">Many Are In Need Of Your Helping Hand.</h1>

                                          </div>

                                       </div>

                                    </div>

                                 </div>

                              </div>

                           </div>

                        </div>

                        <div class="tab-pane fade" id="nav-health" role="tabpanel" aria-labelledby="nav-health-tab">

                           <div class="tab-slider">

                              <div class="tab-slider-inner" style=" width:100%;     background: url({{asset('assets/images/bg/banner.jpg')}}) no-repeat;">

                                 <div class="container">

                                    <div class="row justify-content-center">

                                       <div class="col-lg-12 col-md-12">

                                          <div class="block text-center">

                                             <h1 class="animated fadeInUp mb-4">New hope for <br>near future</h1>

                                          </div>

                                       </div>

                                    </div>

                                 </div>

                              </div>

                              <div class="tab-slider-inner" style="width:100%; background: url({{asset('assets/images/bg/banner-1.jpg')}}) no-repeat;">

                                 <div class="container">

                                    <div class="row justify-content-center">

                                       <div class="col-lg-12 col-md-12">

                                          <div class="block text-center">

                                             <h1 class="animated fadeInUp mb-4">Open Your Heart To Those In Need.</h1>

                                          </div>

                                       </div>

                                    </div>

                                 </div>

                              </div>

                              <div class="tab-slider-inner" style=" height:500px; width:100%;  background: url({{asset('assets/images/bg/banner-2.jpg')}}) no-repeat;">

                                 <div class="container">

                                    <div class="row justify-content-center">

                                       <div class="col-lg-12 col-md-12">

                                          <div class="block text-center">

                                             <h1 class="animated fadeInUp mb-4">Many Are In Need Of Your Helping Hand.</h1>

                                          </div>

                                       </div>

                                    </div>

                                 </div>

                              </div>

                           </div>

                        </div>

                        <div class="tab-pane fade" id="nav-livelihood" role="tabpanel" aria-labelledby="nav-livelihood-tab">

							<div class="tab-slider">

								<div class="tab-slider-inner" style=" height:500px; width:100%;      background: url({{asset('assets/images/bg/banner.jpg')}}) no-repeat;">

									<div class="container">

										<div class="row justify-content-center">

										<div class="col-lg-12 col-md-12">

											<div class="block text-center">

												<h1 class="animated fadeInUp mb-4">New hope for <br>near future</h1>

											</div>

										</div>

										</div>

									</div>

								</div>

								<div class="tab-slider-inner" style=" height:500px; width:100%;  background: url({{asset('assets/images/bg/banner-1.jpg')}}) no-repeat;">

									<div class="container">

										<div class="row justify-content-center">

										<div class="col-lg-12 col-md-12">

											<div class="block text-center">

												<h1 class="animated fadeInUp mb-4">Open Your Heart To Those In Need.</h1>

											</div>

										</div>

										</div>

									</div>

								</div>

								<div class="tab-slider-inner" style=" height:500px; width:100%;  background: url({{asset('assets/images/bg/banner-2.jpg')}}) no-repeat;">

									<div class="container">

										<div class="row justify-content-center">

										<div class="col-lg-12 col-md-12">

											<div class="block text-center">

												<h1 class="animated fadeInUp mb-4">Many Are In Need Of Your Helping Hand.</h1>

											</div>

										</div>

										</div>

									</div>

								</div>

							</div>

						</div>

						<div class="tab-pane fade" id="nav-Woman-Empowerment" role="tabpanel" aria-labelledby="nav-Woman-Empowerment

                  -tab">

							<div class="tab-slider">

								<div class="tab-slider-inner" style=" width:100%;    background: url({{asset('assets/images/bg/banner.jpg')}}) no-repeat;">

									<div class="container">

										<div class="row justify-content-center">

										<div class="col-lg-12 col-md-12">

											<div class="block text-center">

												<h1 class="animated fadeInUp mb-4">New hope for <br>near future</h1>

											</div>

										</div>

										</div>

									</div>

								</div>

								<div class="tab-slider-inner" style=" width:100%;    background: url({{asset('assets/images/bg/banner-1.jpg')}}) no-repeat;">

									<div class="container">

										<div class="row justify-content-center">

										<div class="col-lg-12 col-md-12">

											<div class="block text-center">

												<h1 class="animated fadeInUp mb-4">Open Your Heart To Those In Need.</h1>

											</div>

										</div>

										</div>

									</div>

								</div>

								<div class="tab-slider-inner" style="  width:100%;  background: url({{asset('assets/images/bg/banner-2.jpg')}}) no-repeat;">

									<div class="container">

										<div class="row justify-content-center">

										<div class="col-lg-12 col-md-12">

											<div class="block text-center">

												<h1 class="animated fadeInUp mb-4">Many Are In Need Of Your Helping Hand.</h1>

											</div>

										</div>

										</div>

									</div>

								</div>

							</div>

						</div>



                     </div>

                  </div>

               </div>

            </div>

         </div>

      </div>

   </div>

</section>

<section>

   <div class="container">

      <div class="row">

         <div class="col-lg-12">

            <div class="section-divider"></div>

         </div>

      </div>

   </div>

</section>
@if($pagesettings[0]->blog_status)
<section class="section latest-blog">

   <div class="container">

      <div class="row justify-content-center">

         <div class="col-lg-7 text-center">

            <div class="section-title">

               <span class="h6 text-center">{{$languages->blog_title}}</span>

               <h2 class="mt-3 content-title">{{$languages->blog_text}}</h2>

            </div>

         </div>

      </div>

      <div class="row justify-content-center">
         @foreach($blogs as $blog)
         <div class="col-lg-4 col-md-6 mb-5 mb-lg-0 ">

            <div class="card blog-item ">

               <img src="{{url('/')}}/assets/images/blog/{{$blog->featured_image}}" alt="" class="img-fluid" style="height:230px;">

               <div class="card-body mt-2  ">

                  {{--  <span class="text-sm text-color text-uppercase font-weight-bold">{{date('d M Y',strtotime($blog->created_at))}}</span>  --}}

                  <h3 class="mb-3 text-center"><a href="{{url('/')}}/event/{{$blog->id}}" class="text-dark">{{$blog->title}}</a></h3>

                  <p>{{substr(strip_tags($blog->details),0,125)}}</p>

               </div>

            </div>

         </div>
         @endforeach
       
      </div>

   </div>

</section>
@endif
<!-- Section About End -->

<div class="cta-block section">

   <div class="container">

      <div class="row justify-content-center ">

         <div class="col-lg-7 col-md-12">

            <div class="cta-content text-center">

               <i class="icofont-diamond text-lg text-color"></i>

               <h2 class="text-white text-lg mb-5 mt-3">We can’t help everyone, but everyone can help someone</h2>
             <iframe  src="https://www.youtube.com/embed/EGcSGp54FSU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>


               <a href="{{url('campaign/5/donate')}}" class="btn btn-main rounded">Make a donation</a>

            </div>

         </div>

      </div>

   </div>

</div>



<!-- Section About Start -->

<section class="section causes mt-5 mb-5">

   <div class="container">

 

      <div class="row">

         <div class="col-lg-4 accreditations">



         <h3 class="text-center">  No Hunger </h3>

     <div class="accreditations-slider">

            <div class="card mb-3 accreditations-item">

               <div class="row no-gutters">

                 <img src="{{asset('assets/images/food.jpeg')}}" class="w-100 mt-10" alt="...">

                  <div class="card-body">

                     <h3 class="mb-3"><a href="#" >No Hunger</a></h3>

                    

                     <p class="card-text mb-4">No Hungry Child Free Food Program is focused towards distributing hot, nutritious and fresh food to poor, needy & hungry children across pockets of poverty in India.   </p>

                     

                  </div>

               </div>

             </div>



            <div class="card mb-3 accreditations-item">

               <div class="row no-gutters">

                  <img src="{{asset('assets/images/food-2.jpeg')}}" class="img-fluid w-100" alt="...">

                  <div class="card-body">

                     <h3 class="mb-3"><a href="#">No Hunger</a></h3>

                  

                     <p class="card-text mb-4">No Hungry Child Free Food Program is focused towards distributing hot, nutritious and fresh food to poor, needy & hungry children across pockets of poverty in India.  </p>

                    

                  </div>

               </div>

            </div>



            <div class="card mb-3 accreditations-item">

               <div class="row no-gutters">

                  <img src="{{asset('assets/images/food-3.jpeg')}}" class="img-fluid w-100" alt="...">

                  <div class="card-body">

                     <h3 class="mb-3"><a href="#">No Hunger</a></h3>

                   

                     <p class="card-text mb-4">No Hungry Child Free Food Program is focused towards distributing hot, nutritious and fresh food to poor, needy & hungry children across pockets of poverty in India.  </p>

                   

                  </div>

               </div>

            </div>

			</div>

         </div>




         <div class="col-lg-4 accreditations">

            <h3 class="text-center">  Educational Rally </h3>
   
   
   
            <div class="accreditations-slider">
   
   
               <div class="card mb-3 accreditations-item">
   
                  <div class="row no-gutters">
   
                     <img src="{{asset('assets/images/rally.jpeg')}}" class="img-fluid w-100" alt="..." style="height:270px;">
   
                     <div class="card-body">               

                        <h3 class="mb-3 text-center"><a href="#">Rally Event</a></h3>

                        <p class="card-text mb-4">
   
                           Saying that “Safe School” is the right of each and every student, people has said that the Aasraa Society is implementing the “Safe School Access” programme, which aims toward safety of students.  
   
                     </p>
   
                     
   
                     </div>
   
                  </div>
   
               </div>
               
   
   
   
               <div class="card mb-3 accreditations-item">
   
                  <div class="row no-gutters">
   
                     <img src="{{asset('assets/images/rally_2.jpeg')}}" class="img-fluid w-100"  alt="..." style="height:270px;">
   
                     <div class="card-body">               

                        <h3 class="mb-3 text-center"><a href="#">Rally Event</a></h3>

                        <p class="card-text mb-4">
   
                           Saying that “Safe School” is the right of each and every student, people has said that the Aasraa Society is implementing the “Safe School Access” programme, which aims toward safety of students.  
   
                     </p>
   
                           
   
                     </div>
   
   
                  </div>
   
               </div>
   
            </div>
         </div>
 
         <div class="col-lg-4 accreditations">

            <h3 class="text-center">  Awards/Recognitions </h3>



         <div class="accreditations-slider">


            <div class="card mb-3 accreditations-item">

               <div class="row no-gutters">

                  <img src="{{asset('assets/images/service/award.jpeg')}}" class="img-fluid w-100" alt="..." style="height:270px;">

                  <div class="card-body">

                     <h3 class="mb-3 text-center"><a href="#">Awards/Recognitions</a></h3>

                  

                     <p class="card-text mb-4">Aasra Foundation’s legacy of humanitarianism and service has led to recognition by the international community as we have been named one of the most efficient and wide-reaching non-profit organizations worldwide. </p>

                    

                  </div>

               </div>

            </div>



            <div class="card mb-3 accreditations-item">

               <div class="row no-gutters">

                  <img src="{{asset('assets/images/service/award_2.jpeg')}}" class="img-fluid w-100" alt="..." style="height:270px;">

                  <div class="card-body">

                     <h3 class="mb-3 text-center"><a href="#">Awards/Recognitions</a></h3>

                   

                     <p class="card-text mb-4">Aasra Foundation’s legacy of humanitarianism and service has led to recognition by the international community as we have been named one of the most efficient and wide-reaching non-profit organizations worldwide. </p>


                     

                   

                  </div>

               </div>

            </div>

			</div>





         </div>

      </div>

   </div>

</section>





@endsection



