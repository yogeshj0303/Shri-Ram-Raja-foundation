<style>
.app-brand{
    display: flex !important;
    align-items: center;
}
    .app-brand a img {
    max-width: unset !important;
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.app-brand a {
    width: 45% !important;}
    .app-brand .brand-name {
    font-size: 16px !important;
    color: #7D2310 !important;
    font-weight: 800;
    margin-left: 0.31rem;
}
.left-sidebar.sidebar-light .sidebar .sidebar-inner > li > a {
    color: #333 !important;
}
.sidebar .nav > li > a i {color:#7D2310 !important;}

@media (max-width:768px){
    .app-brand a {
    width: 35% !important;
}
    
    .left-sidebar{
        transform: translateX(-285px) !important;
}
}

</style>
<link href="{{asset('assets/logo/HRF.png')}}" rel="shortcut icon" />
        <!-- ====================================
          ——— LEFT SIDEBAR WITH OUT FOOTER
        ===================================== -->
        <aside class="left-sidebar sidebar-light" id="left-sidebar">
          <div id="sidebar" class="sidebar sidebar-with-footer">
            <!-- Aplication Brand -->
            <div class="app-brand text-center">
              <a href="{{url('newdashboard')}}">
                <img src="{{asset('assets/logo/HRF.png')}}" alt="">
                <!--<span class="brand-name">MONO</span>-->
              </a>
              <span class="brand-name">Harda Rewa Foundation</span>
            </div>
            <!-- begin sidebar scrollbar -->
            <div class="sidebar-left" data-simplebar style="height: 100%;">
              <!-- sidebar menu -->
              <ul class="nav sidebar-inner" id="sidebar-menu">
                

                
                  <li class="" >
                    <a class="sidenav-item-link" href="{{url('newdashboard')}}">
                      <i class="mdi mdi-briefcase-account-outline"></i>
                      <span class="nav-text"> Dashboard</span>
                    </a>
                  </li>
                

                 <li>
                    <a class="sidenav-item-link" href="{{route('showEvent')}}">
                      <i class="mdi mdi-account-group"></i>
                      <span class="nav-text">Events</span>
                    </a>
                  </li>

                        <li>
                    <a class="sidenav-item-link" href="{{route('showCampaigns')}}">
                      <i class="mdi mdi-flag-variant"></i>
                      <span class="nav-text">Compaign</span>
                    </a>
                  </li>
                
                         <li>
                    <a class="sidenav-item-link" href="{{route('showMedia')}}">
                      <i class="mdi mdi-animation-play"></i>
                      <span class="nav-text">Media</span>
                    </a>
                  </li>
                   
                         <li>
                    <a class="sidenav-item-link" href="{{route('showAwards')}}">
                      <i class="mdi mdi-image-area"></i>
                      <span class="nav-text">Awards</span>
                    </a>
                  </li>
                         <li>
                    <a class="sidenav-item-link" href="{{route('contacts')}}">
                      <i class="mdi mdi-phone-classic"></i>
                      <span class="nav-text">Contacts</span>
                    </a>
                  </li>
                  
                            <li>
                    <a class="sidenav-item-link" href="{{route('showVolunteer')}}">
                      <i class="mdi mdi-human-handsdown"></i>
                      <span class="nav-text">Volunteer</span>
                    </a>
                  </li>
              </ul>

            </div>

          </div>
        </aside>